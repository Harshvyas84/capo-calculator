# Capo Calculator
This apps finds chord which is played using capo on a perticular fret is which standard chord.
<br>
It also finds open chord for a any given fret position and standard guitar chord

### App UI:

 <p align  = "center">
<img src="https://github.com/Kinshuk1202/Capo-Calculator/assets/111125490/e41a2653-f05a-42e2-bcba-4af776a35b06" width="300" height="600" /> 
  &nbsp; &nbsp; &nbsp;  &nbsp; &nbsp; &nbsp; 
  <img src="https://github.com/Kinshuk1202/Capo-Calculator/assets/111125490/63ac5822-a74e-48cc-abe9-358fa8a07669" width="300" height="600" />
    &nbsp; &nbsp; &nbsp;  &nbsp; &nbsp; &nbsp; 
  <img src="https://github.com/Kinshuk1202/Capo-Calculator/assets/111125490/d9319c90-d447-4bde-bec1-195a6cdfd190" width="300" height="600" />
</p>
